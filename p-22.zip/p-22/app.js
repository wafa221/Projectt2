var section = document.querySelectorAll("section");
onscroll= function()
{
	var scrollPosition=document.documentElement.scrollTop;
	sections.forEach((section) => {
if (
     scrollPosition >= section.offsetTop - section.offsetHeight &&
        scrollPosition <
     section.offsetTop + section.offsetHeight - section.offsetHeight
	 )
	    {
		 
		 var currentId= section.attributes.id.value;
          removeAllActiveClasses();
		  addActiveClass (currentId);
		}
		
	});
	
};

   var removeAllActiveClasses = function () {
   document.querySelectorAll("nav a").forEach( (elemet) => {
   elemet.classList.remove("active");
   
   
   });
   };
   
   var addActiveClass = function (id) {
   var selector =' nav a[href="#${id}"] ';
   document.querySelector(selector).classList.add("active");
   };
     var navLinks = document.querySelectorAll("nav a");
	 
     navLinks.forEach((link) => {
        link.addEventListener("click", (elemet) => 
        { elemet.preventDefault();
        var currentId = e.target.attributes.href.value;
        var section = document.querySelector (currentId); 
         var sectionPos = section.offsetTop;
		});

	 });
	 
	 const absicsection=document.querySelector("div.absicsection");
     console.log(absicsection);
     const rect=absicsection.getBoundingClientRect();
     console.log(rect);

     window.addEventListener("scroll", function () { 
	 console.log(window.innerHeight);
     console.log(absicsection.getBoundingClientRect().top);
	 
	 });